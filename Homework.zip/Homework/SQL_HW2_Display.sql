--display data
SELECT * from Books
SELECT * from Costs
SELECT * from Formats
SELECT * from Authors
SELECT * from Publishers
SELECT * from Suppliers