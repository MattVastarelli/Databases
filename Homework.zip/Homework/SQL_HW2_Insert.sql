USE store

INSERT Authors (authorName)
VALUES ('jk rowling')

INSERT Authors (authorName)
VALUES ('Mark Twain')

INSERT Authors (authorName)
VALUES ('C.S Lewis')

INSERT Publishers(publisherName)
VALUES ('penguin')

INSERT Publishers(publisherName)
VALUES ('HarperCollins')

INSERT Publishers(publisherName)
VALUES ('Penguin Random House')

INSERT Formats(bookFormat)
VALUES ('ebook')

INSERT Formats(bookFormat)
VALUES ('Print')

INSERT Suppliers(supplierName)
VALUES ('UNH')

INSERT Suppliers(supplierName)
VALUES ('Amazon')

INSERT Suppliers(supplierName)
VALUES ('Ebay')

INSERT Costs(costs, supplier)
VALUES (11, 'UNH')

INSERT Costs(costs, supplier)
VALUES (21, 'Ebay')

INSERT Costs(costs, supplier)
VALUES (10, 'Ebay')

INSERT Costs(costs, supplier)
VALUES (10, 'Amazon')


INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (1,'Harry Potter', 'jk rowling', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (43,'Do Androids Dream of Electric Sheep? ', 'jk rowling', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (432,'The Hitchhikers Guide to the Galaxy ', 'Mark Twain', 2, 'Amazon', 'penguin','print',10)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (3452,'The Hitchhikers Guide to the Galaxy ', 'Mark Twain', 3, 'Ebay', 'HarperCollins','ebook',21)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (34526,'Something Wicked This Way Comes ', 'C.S Lewis', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (422223,'I Was Told Thered Be Cake', 'C.S Lewis', 2, 'Amazon', 'penguin','print',10)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (411132,'The Curious Incident of the Dog in the Night-Time', 'Mark Twain', 3, 'Ebay', 'Penguin Random House','print',21)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (3432352,'The Hollow Chocolate Bunnies of the Apocalypse ', 'jk rowling', 3, 'Ebay', 'Penguin Random House','ebook',21)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (62223,'The Perks of Being a Wallflower', 'Mark Twain', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (991132,'To Kill a Mockingbird', 'C.S Lewis', 3, 'Ebay', 'Penguin Random House','ebook',21)
