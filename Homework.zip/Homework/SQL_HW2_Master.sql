CREATE DATABASE store

USE store

CREATE Table Books (
	isbn			varchar(15),
	currentPrice	money,
	bookDescription text,
	title			nvarchar(50),
	publisedDate	date,
	uniqueID		varchar(50) NOT NULL,
	CONSTRAINT PK_Books_uniqueID PRIMARY KEY CLUSTERED (uniqueID) 		
)

CREATE TABLE Suppliers (
	supplierName	nvarchar(50)	NOT NULL,
	CONSTRAINT PK_Suppliers_supplierName PRIMARY KEY CLUSTERED (supplierName)
)

CREATE TABLE Authors (
	firstPublishedYear	date,
	dateOfBirth			date,
	bio					text,
	penName				nvarchar(50),
	authorName			nvarchar(50) NOT NULL,
	contactInfo			nvarchar(25),
	CONSTRAINT PK_Authors_authorName PRIMARY KEY CLUSTERED (authorName) 
)

CREATE TABLE Publishers (
	publisherName	nvarchar(50) NOT NULL,
	CONSTRAINT PK_Publishers_publisherName PRIMARY KEY CLUSTERED (publisherName)
)

CREATE TABLE Formats (
	bookFormat	nvarchar(50),
	CONSTRAINT PK_Formats_bookFormat PRIMARY KEY CLUSTERED (bookFormat)
)

CREATE TABLE Costs (
	cost	money NOT NULL,
)

ALTER TABLE Costs
ADD bookID VARCHAR(50) NOT NULL;

ALTER TABLE Costs
ADD CONSTRAINT FK_Books_uniqueID FOREIGN KEY (bookID)
	REFERENCES Books (uniqueID)     
    ON DELETE CASCADE    
    ON UPDATE CASCADE    
	;

ALTER TABLE Books
ADD author NVARCHAR(50) NOT NULL;

ALTER TABLE Books
ADD publisher NVARCHAR(50) NOT NULL;

ALTER TABLE Books
ADD formats NVARCHAR(50) NOT NULL;

ALTER TABLE Books
ADD supplier VARCHAR(50) NOT NULL;

ALTER TABLE Books
ADD costs money NOT NULL;

ALTER TABLE Books
ADD CONSTRAINT FK_Author_authorName FOREIGN KEY (author)
	REFERENCES Authors (AuthorName)     
    ON DELETE CASCADE    
    ON UPDATE CASCADE    
	;

ALTER TABLE Books
ADD CONSTRAINT FK_Supplier_supplier FOREIGN KEY (Supplier)
	REFERENCES Suppliers (suppliername)     
    ON DELETE CASCADE    
    ON UPDATE CASCADE    
	;

ALTER TABLE Books
ADD CONSTRAINT FK_Publisher_publisher FOREIGN KEY (publisher)
	REFERENCES Publishers (publisherName)     
    ON DELETE CASCADE    
    ON UPDATE CASCADE    
	;
ALTER TABLE Books
ADD CONSTRAINT FK_Format_format FOREIGN KEY (formats)
	REFERENCES Formats (bookFormat)     
    ON DELETE CASCADE    
    ON UPDATE CASCADE    
	;

ALTER TABLE Costs
ADD CONSTRAINT PK_Costs_Costs PRIMARY KEY CLUSTERED (costs);  

ALTER TABLE Books
ADD CONSTRAINT FK_Costs_costs FOREIGN KEY (costs)
	REFERENCES Costs (costs)     
    ON DELETE NO ACTION    
    ON UPDATE NO ACTION    
	;

ALTER TABLE Costs
ADD supplier VARCHAR(50) NOT NULL;

ALTER TABLE Costs
ADD CONSTRAINT FK_Supplier_suppliername FOREIGN KEY (Supplier)
	REFERENCES Suppliers (suppliername)     
    ON DELETE NO ACTION    
    ON UPDATE NO ACTION    
	;

ALTER TABLE Books
ADD margin AS (currentPrice - costs);

ALTER TABLE Books
DROP COLUMN margin  

ALTER TABLE Books
ADD margin money

ALTER TABLE Books
DROP CONSTRAINT FK_Costs_Costs

ALTER TABLE Costs
DROP CONSTRAINT PK_Costs_Costs

ALTER TABLE Suppliers
ADD SupplierID int IDENTITY(1,1)

ALTER TABLE Books
DROP CONSTRAINT FK_Supplier_supplier

ALTER TABLE Costs
DROP CONSTRAINT FK_Supplier_suppliername

ALTER TABLE Suppliers
DROP CONSTRAINT PK_Suppliers_supplierName

ALTER TABLE Suppliers
ADD CONSTRAINT pkSuppliers PRIMARY KEY (SupplierID)

ALTER TABLE Books
ADD SupplierID int NOT NULL

ALTER TABLE Books
ADD CONSTRAINT fkSuppliers FOREIGN KEY (supplierID)
REFERENCES Suppliers (SupplierID)

ALTER TABLE Books
DROP COLUMN supplier

ALTER table Costs
ADD CONSTRAINT PKcosts PRIMARY KEY CLUSTERED (bookID, supplier)

ALTER TABLE Books
ADD supplier varchar(50) NOT NULL

ALTER TABLE Books
ADD CONSTRAINT fkcosts FOREIGN KEY (uniqueID, supplier)
REFERENCES Costs (bookID, supplier)
 
ALTER TABLE Books
ADD margin money

ALTER TABLE Books
DROP CONSTRAINT fkcosts

ALTER TABLE Costs
DROP CONSTRAINT PKcosts

ALTER TABLE Costs
DROP CONSTRAINT FK_Books_uniqueID

ALTER TABLE Costs
DROP COLUMN bookID

ALTER TABLE Costs
ADD bookID varchar(50)

ALTER table Costs
ADD CONSTRAINT PKcosts PRIMARY KEY CLUSTERED (costs, supplier)

ALTER TABLE Books
ADD CONSTRAINT fkcosts FOREIGN KEY (costs, supplier)
REFERENCES Costs (costs, supplier)

-- Insert Data

INSERT Authors (authorName)
VALUES ('jk rowling')

INSERT Authors (authorName)
VALUES ('Mark Twain')

INSERT Authors (authorName)
VALUES ('C.S Lewis')

INSERT Publishers(publisherName)
VALUES ('penguin')

INSERT Publishers(publisherName)
VALUES ('HarperCollins')

INSERT Publishers(publisherName)
VALUES ('Penguin Random House')

INSERT Formats(bookFormat)
VALUES ('ebook')

INSERT Formats(bookFormat)
VALUES ('Print')

INSERT Suppliers(supplierName)
VALUES ('UNH')

INSERT Suppliers(supplierName)
VALUES ('Amazon')

INSERT Suppliers(supplierName)
VALUES ('Ebay')

INSERT Costs(costs, supplier)
VALUES (11, 'UNH')

INSERT Costs(costs, supplier)
VALUES (21, 'Ebay')

INSERT Costs(costs, supplier)
VALUES (10, 'Ebay')

INSERT Costs(costs, supplier)
VALUES (10, 'Amazon')


INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (1,'Harry Potter', 'jk rowling', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (43,'Do Androids Dream of Electric Sheep? ', 'jk rowling', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (432,'The Hitchhikers Guide to the Galaxy ', 'Mark Twain', 2, 'Amazon', 'penguin','print',10)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (3452,'The Hitchhikers Guide to the Galaxy ', 'Mark Twain', 3, 'Ebay', 'HarperCollins','ebook',21)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (34526,'Something Wicked This Way Comes ', 'C.S Lewis', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (422223,'I Was Told Thered Be Cake', 'C.S Lewis', 2, 'Amazon', 'penguin','print',10)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (411132,'The Curious Incident of the Dog in the Night-Time', 'Mark Twain', 3, 'Ebay', 'Penguin Random House','print',21)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (3432352,'The Hollow Chocolate Bunnies of the Apocalypse ', 'jk rowling', 3, 'Ebay', 'Penguin Random House','ebook',21)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (62223,'The Perks of Being a Wallflower', 'Mark Twain', 1, 'UNH', 'penguin','ebook',11)

INSERT Books (uniqueID, title, author, SupplierID, supplier, publisher, formats, costs)
VALUES (991132,'To Kill a Mockingbird', 'C.S Lewis', 3, 'Ebay', 'Penguin Random House','ebook',21)

--display data
SELECT * from Books
SELECT * from Costs
SELECT * from Formats
SELECT * from Authors
SELECT * from Publishers
SELECT * from Suppliers